﻿namespace MotorDrivingSchoolSystemCSharp
{
    partial class HomeAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.AddTutorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AssignTutorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewTutorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.MenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddTutorToolStripMenuItem,
            this.AddStudentToolStripMenuItem,
            this.AssignTutorToolStripMenuItem,
            this.ViewStudentToolStripMenuItem,
            this.ViewTutorToolStripMenuItem,
            this.ExitToolStripMenuItem});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(618, 24);
            this.MenuStrip1.TabIndex = 1;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // AddTutorToolStripMenuItem
            // 
            this.AddTutorToolStripMenuItem.Name = "AddTutorToolStripMenuItem";
            this.AddTutorToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.AddTutorToolStripMenuItem.Text = "Add Tutor";
            this.AddTutorToolStripMenuItem.Click += new System.EventHandler(this.AddTutorToolStripMenuItem_Click);
            // 
            // AddStudentToolStripMenuItem
            // 
            this.AddStudentToolStripMenuItem.Name = "AddStudentToolStripMenuItem";
            this.AddStudentToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.AddStudentToolStripMenuItem.Text = "Add Student";
            this.AddStudentToolStripMenuItem.Click += new System.EventHandler(this.AddStudentToolStripMenuItem_Click);
            // 
            // AssignTutorToolStripMenuItem
            // 
            this.AssignTutorToolStripMenuItem.Name = "AssignTutorToolStripMenuItem";
            this.AssignTutorToolStripMenuItem.Size = new System.Drawing.Size(107, 20);
            this.AssignTutorToolStripMenuItem.Text = "Assign Tutor";
            this.AssignTutorToolStripMenuItem.Click += new System.EventHandler(this.AssignTutorToolStripMenuItem_Click);
            // 
            // ViewStudentToolStripMenuItem
            // 
            this.ViewStudentToolStripMenuItem.Name = "ViewStudentToolStripMenuItem";
            this.ViewStudentToolStripMenuItem.Size = new System.Drawing.Size(109, 20);
            this.ViewStudentToolStripMenuItem.Text = "View Student";
            this.ViewStudentToolStripMenuItem.Click += new System.EventHandler(this.ViewStudentToolStripMenuItem_Click);
            // 
            // ViewTutorToolStripMenuItem
            // 
            this.ViewTutorToolStripMenuItem.Name = "ViewTutorToolStripMenuItem";
            this.ViewTutorToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.ViewTutorToolStripMenuItem.Text = "View Tutor";
            this.ViewTutorToolStripMenuItem.Click += new System.EventHandler(this.ViewTutorToolStripMenuItem_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MotorDrivingSchoolSystemCSharp.Properties.Resources.kashipara;
            this.pictureBox1.Location = new System.Drawing.Point(506, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 87;
            this.pictureBox1.TabStop = false;
            // 
            // HomeAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 458);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.MenuStrip1);
            this.Name = "HomeAdmin";
            this.Text = "HomeAdmin";
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem AddTutorToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem AddStudentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem AssignTutorToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ViewStudentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ViewTutorToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}